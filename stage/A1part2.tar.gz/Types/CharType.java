package Types;

public class CharType extends Type
{
    public CharType () { }
    
    public String toString()
    {
        return "char";
    }
}