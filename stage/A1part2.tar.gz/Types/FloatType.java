package Types;

public class FloatType extends Type
{
    public FloatType () { }
    
    public String toString()
    {
        return "float";
    }
}