package Types;

public abstract class Type
{
    public abstract String toString();
}