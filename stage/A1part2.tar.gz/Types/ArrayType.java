package Types;

public class ArrayType extends Type
{
    public String toString()
    {
        return "";
    }
}