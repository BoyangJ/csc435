package AST;

public class FunctionExpression extends Expression
{
    public String name;
    public ExpressionList eList;

    public FunctionExpression (String n, ExpressionList el)
    {
        name = n;
        eList = el;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}