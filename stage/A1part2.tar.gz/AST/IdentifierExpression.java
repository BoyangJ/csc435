package AST;

public class IdentifierExpression extends Expression 
{
    public String name;
    
    public IdentifierExpression (String n)
    {
        name = n;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}