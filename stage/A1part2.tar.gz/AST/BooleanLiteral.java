package AST;

public class BooleanLiteral extends Expression
{
    public Boolean value;

    public BooleanLiteral (Boolean b)
    {
        value = b;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}