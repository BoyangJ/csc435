package AST;

public class LessThanExpression extends Expression
{
    public Expression expr1;
    public Expression expr2;

    public LessThanExpression (Expression e1, Expression e2)
    {
        expr1 = e1;
        expr2 = e2;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}