package AST;

public class ReturnStatement extends Statement
{
    public Expression expr;

    public ReturnStatement ()
    {
        expr = null;
    }

    public ReturnStatement (Expression e)
    {
        expr = e;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}