package AST;

public class IntegerLiteral extends Expression
{
    public Integer value;

    public IntegerLiteral (Integer i)
    {
        value = i;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}