package AST;

public class FloatLiteral extends Expression
{
    public Float value;

    public FloatLiteral (Float f)
    {
        value = f;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}