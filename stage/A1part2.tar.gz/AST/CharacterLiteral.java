package AST;

public class CharacterLiteral extends Expression
{
    public Character value;

    public CharacterLiteral (Character c)
    {
        value = c;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}