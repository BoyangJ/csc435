package AST;

public class Identifier extends ASTNode
{
    public String name;

    public Identifier (String n)
    {
        name = n;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}