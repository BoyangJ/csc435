package AST;

public class AssignmentStatement extends Statement
{
    public Identifier name;
    public Expression expr;

    public AssignmentStatement (Identifier i, Expression e)
    {
        name = i;
        expr = e;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}