package AST;

public class StringLiteral extends Expression
{
    public String value;

    public StringLiteral (String s)
    {
        value = s;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}