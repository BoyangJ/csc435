package AST;

import Types.*;

public class TypeNode extends ASTNode
{
    public Type type;
    public IntegerLiteral index;

    public TypeNode (Type t)
    {
        type = t;
    }

    public TypeNode (Type t, IntegerLiteral i)
    {
        type = t;
        index = i;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}