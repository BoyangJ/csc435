package AST;

public class ASTNode
{
    Program p;
}