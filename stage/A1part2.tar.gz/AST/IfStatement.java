package AST;

public class IfStatement extends Statement
{
    public Expression expr;
    public Block ifBlock;
    public Block elseBlock;

    public IfStatement (Expression e, Block b1)
    {
        expr = e;
        ifBlock = b1;
    }

    public IfStatement (Expression e, Block b1, Block b2)
    {
        expr = e;
        ifBlock = b1;
        elseBlock = b2;
    }

    public void accept (Visitor v)
    {
        v.visit(this);
    }
}