package AST;

public class Literal extends ASTNode
{
    
}