package AST;

public class ASTNode
{
    Program p;

    public int line;
    public int offset;
}