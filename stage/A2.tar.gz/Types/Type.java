package Types;

public abstract class Type
{
    public Type type;
    public int size;
    
    public abstract String toString();
}