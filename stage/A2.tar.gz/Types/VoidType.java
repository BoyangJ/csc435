package Types;

public class VoidType extends Type
{
    public VoidType () { }
    
    public String toString()
    {
        return "void";
    }
}