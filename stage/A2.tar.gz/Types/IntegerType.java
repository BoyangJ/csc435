package Types;

public class IntegerType extends Type
{
    public IntegerType () { }
    
    public String toString()
    {
        return "int";
    }
}