package Types;

public class BooleanType extends Type
{
    public BooleanType () { }
    
    public String toString()
    {
        return "boolean";
    }
}