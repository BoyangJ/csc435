package Types;

public class StringType extends Type
{
    public StringType () { } 
    
    public String toString()
    {
        return "string";
    }
}